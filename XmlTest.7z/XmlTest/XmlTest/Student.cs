﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XmlTest
{
    class Student
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Gender { get; set; }
        public int Age { get; set; }

        public static IEnumerable<Student> GetAllStudents()
        {
            return new List<Student>
                {
                    new Student{Id = 100, Name = "Axel", Gender = "Male", Age = 22},
                    new Student{Id = 101, Name = "John", Gender = "Male", Age = 24},
                    new Student{Id = 102, Name = "Anna", Gender = "Female", Age = 23},
                    new Student{Id = 103, Name = "Julia", Gender = "Female", Age = 21},
                    new Student{Id = 104, Name = "Andrei", Gender = "Male", Age = 22}
            };
        }
    }
}
