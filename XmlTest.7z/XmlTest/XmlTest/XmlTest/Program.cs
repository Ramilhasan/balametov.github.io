﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
namespace XmlTest
{
    class Program
    {
        static void Main(string[] args)
        {
            var xmlDoc = new XDocument(new XDeclaration("1.0", "utf-8", "yes"),
                                       new XElement("footballclub",
                                                    footballclub.GetAllfootballclub().Select(
                                                        item => new XElement("footballclub", new XAttribute("Id", item.Id),
                                                                             new XElement("Name", item.Name),
                                                                             new XElement("Gender", item.Trainer),
                                                                             new XElement("Age", item.Age),
                                                                             new XElement("Country", item.Country)))));
            xmlDoc.Save(System.IO.Path.Combine(Environment.CurrentDirectory, "xmlDoc.xml"));
            Console.ReadKey();
        }
    }
}
