﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XmlTest
{
    class footballclub
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Trainer { get; set; }
        public int Age { get; set; }
        public string Country { get; set; }

        public static IEnumerable<footballclub> GetAllfootballclub()
        {
            return new List<footballclub>
                {
                    new footballclub{Id = 1, Country = "England", Name = "Arsenal", Trainer = "Arsen", Age = 131},
                    new footballclub{Id = 2, Country = "England", Name = "Chelsea", Trainer = "Conte", Age = 112},
                    new footballclub{Id = 3, Country = "Spain", Name = "Barcelona", Trainer = "Ernesto", Age = 118},
                    new footballclub{Id = 4, Country = "Italy", Name = "Juventus", Trainer = "Allegri", Age = 120},
                    new footballclub{Id = 5, Country = "Russia", Name = "Spartak Moscow", Trainer = "Karrera", Age = 95}
            };
        }
    }
}
